﻿//@Author Brock Wright
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RandomGuess
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Random rand = new Random();
            int roll = rand.Next(1, 100);
            Start:
            Console.WriteLine("Please guess a number between 1 and 100. >>");
            string answerAsString = Console.ReadLine();
            int answer = Convert.ToInt32(answerAsString);
            


            if (roll == answer)
            {
                Console.WriteLine("Congratulations! You correctly guessed the right number!");
            }
            else
            {
                Console.WriteLine("You did not guess correctly.");
                goto Start;
            }

            Console.ReadKey();
        }
    }
}
